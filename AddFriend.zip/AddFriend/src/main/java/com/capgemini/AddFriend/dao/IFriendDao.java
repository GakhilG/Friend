package com.capgemini.AddFriend.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.AddFriend.bean.Friend;

@Repository("friendDao")
@Transactional
public interface IFriendDao extends JpaRepository<Friend, Integer> {

}
