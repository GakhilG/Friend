package com.capgemini.AddFriend.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.AddFriend.bean.UserProfile;
import com.capgemini.AddFriend.service.IUserService;

@RestController
@RequestMapping("/api")
public class FriendController {

	@Autowired
	private IUserService userService;
	 
	@GetMapping("/friend/input")
	public ResponseEntity<List<UserProfile>> searchFriend(@Param("input") String input) {
		
		List<UserProfile> users = userService.searchFriend(input);
		
		if(users.isEmpty()) {
			return new ResponseEntity("Sorry no users found",HttpStatus.OK);
		}
 		
		return new ResponseEntity<List<UserProfile>>(users,HttpStatus.OK);
		
	}
	
}
