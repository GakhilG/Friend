package com.capgemini.AddFriend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddFriendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddFriendApplication.class, args);
	}

}

