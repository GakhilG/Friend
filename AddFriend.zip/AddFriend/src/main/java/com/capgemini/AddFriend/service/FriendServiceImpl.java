package com.capgemini.AddFriend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.AddFriend.bean.Friend;
import com.capgemini.AddFriend.bean.UserProfile;
import com.capgemini.AddFriend.dao.IFriendDao;

@Service("friendService")
public class FriendServiceImpl implements IFriendService{

	@Autowired
	IFriendDao friendDao;
	
	

	

}
