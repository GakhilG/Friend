package com.capgemini.AddFriend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.AddFriend.bean.UserProfile;
import com.capgemini.AddFriend.dao.IUserDao;

@Service("userService")
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserDao userDao;
	
	@Override
	public List<UserProfile> searchFriend(String input) {
		return userDao.searchFriend(input);
		
		//return userDao.findAll();
	}

}
