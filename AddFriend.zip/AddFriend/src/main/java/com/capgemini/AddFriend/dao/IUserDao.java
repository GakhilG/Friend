package com.capgemini.AddFriend.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.AddFriend.bean.UserProfile;
@Repository("userDao")
public interface IUserDao extends JpaRepository<UserProfile, Integer> {

	@Query("From UserProfile u where u.userName =:input")
	public List<UserProfile> searchFriend(@Param ("input") String input);
}
