package com.capgemini.AddFriend.service;

import com.capgemini.AddFriend.bean.Friend;
import com.capgemini.AddFriend.bean.UserProfile;

public interface IFriendService {

	
	
}
