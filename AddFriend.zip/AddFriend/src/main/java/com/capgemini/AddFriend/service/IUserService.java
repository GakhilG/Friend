package com.capgemini.AddFriend.service;

import java.util.List;

import com.capgemini.AddFriend.bean.UserProfile;

public interface IUserService {

	List<UserProfile> searchFriend(String input);

	

}
